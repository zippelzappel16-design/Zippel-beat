@echo off
chcp 65001 >nul
title Zippel Beat Studio - Grafikkarte aktivieren
cd /d "%~dp0"
set "VPY=%~dp0demucs-env\Scripts\python.exe"
set "UV=%~dp0tools\uv.exe"
if not exist "%VPY%" (
  echo   Bitte zuerst start.bat einmal ausfuehren.
  pause
  exit /b 1
)
echo.
echo   PyTorch mit Grafikkarten-Support wird installiert (ca. 3 GB Download) ...
echo.
set "CC="
set "NVSMI="
for %%X in (nvidia-smi.exe) do set "NVSMI=%%~$PATH:X"
if not defined NVSMI if exist "%SystemRoot%\Sysnative\nvidia-smi.exe" set "NVSMI=%SystemRoot%\Sysnative\nvidia-smi.exe"
if not defined NVSMI if exist "%SystemRoot%\System32\nvidia-smi.exe" set "NVSMI=%SystemRoot%\System32\nvidia-smi.exe"
for /f "tokens=1 delims=." %%A in ('""%NVSMI%"" --query-gpu^=compute_cap --format^=csv^,noheader 2^>nul') do if not defined CC set "CC=%%A"
set "CU=cu126"
if defined CC if %CC% GEQ 10 set "CU=cu128"
for /f "delims=" %%N in ('""%NVSMI%"" --query-gpu^=name --format^=csv^,noheader 2^>nul') do if not defined GPUNAME set "GPUNAME=%%N"
echo   Grafikkarte: %GPUNAME%, Paket: %CU%
"%UV%" pip install --python "%VPY%" --reinstall-package torch --reinstall-package torchaudio torch torchaudio --index-url https://download.pytorch.org/whl/%CU% || "%UV%" pip install --python "%VPY%" --reinstall-package torch --reinstall-package torchaudio torch torchaudio --index-url https://download.pytorch.org/whl/cu128 || goto fail
echo.
if exist "%~dp0tools" echo ok> "%~dp0tools\gpu-geprueft"
"%VPY%" -c "import torch; x=torch.randn(2,2,device='cuda'); print('  Grafikkarte bereit:', torch.cuda.get_device_name(0), '- PyTorch', torch.__version__)" || goto fail
echo.
echo   Fertig. Jetzt start.bat starten.
pause
exit /b 0
:fail
echo.
echo   Das hat nicht geklappt. Schick die Meldung oben an Claude.
echo   Das Studio funktioniert weiterhin, nur langsamer auf dem Prozessor.
pause
exit /b 1
