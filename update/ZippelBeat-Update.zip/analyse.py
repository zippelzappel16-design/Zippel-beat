"""Zippel Beat Studio – Notenplan aus Demucs-Stems.

Drums:   Schläge auf der Drum-Spur erkennen und in Kick / Snare-Clap / Becken einteilen.
Melodie: Gesang mit CREPE (Tonhöhen-KI) in einzelne gesungene Töne zerlegen.
Raster:  Beat-Tracking auf der Drum-Spur, damit alles exakt im Takt liegt.
Ergebnis: chart.json mit fertigen Noten für jede Schwierigkeit und jeden Modus.
"""
import json
import os

import numpy as np

VERSION = 7
SR = 22050
HOP = 256
FPS = SR / HOP
LEVELS = ("easy", "medium", "normal", "pro", "hard")
MIN_STEP = {"easy": 0.45, "normal": 0.22, "hard": 0.11}
# Zwischenstufen: Raster der höheren Stufe, alle Noten der niedrigeren + die stärkere Hälfte vom Rest
BASE_LEVEL = {"medium": "normal", "pro": "hard"}
BETWEEN = {"medium": ("easy", .5), "pro": ("normal", .5)}


def thin_between(grid, level, slots, strength, phase_times):
    """slots: Rasterindizes. Behält das Raster der niedrigeren Stufe komplett und vom Rest den stärksten Anteil."""
    if level not in BETWEEN:
        return set(slots)
    low, frac = BETWEEN[level]
    ql = grid.step_quarters(low)
    phl = best_phase(grid, phase_times, ql) if phase_times else 0
    core = {i for i in slots if (i - phl) % ql == 0}
    rest = sorted((i for i in slots if i not in core), key=lambda i: -strength(i))
    return core | set(rest[:int(round(len(rest) * frac))])


# ---------------------------------------------------------------- Laden
def load_mono(path, sr=SR):
    import librosa
    import sphn
    data, src_sr = sphn.read(path)
    y = data.mean(0) if data.ndim == 2 else data
    return librosa.resample(y.astype(np.float32), orig_sr=src_sr, target_sr=sr)


# ---------------------------------------------------------------- Raster
def beat_grid(drums, mix_len_s):
    import librosa
    env = librosa.onset.onset_strength(y=drums, sr=SR, hop_length=HOP, aggregate=np.median)
    _, beats = librosa.beat.beat_track(onset_envelope=env, sr=SR, hop_length=HOP, units="time", tightness=200)
    beats = np.asarray(beats, dtype=float)
    if len(beats) < 8:
        return None
    period = float(np.median(np.diff(beats)))
    # Lücken (Breaks ohne Drums) mit dem Grundtempo auffüllen
    filled = [beats[0]]
    for b in beats[1:]:
        gap = b - filled[-1]
        n = int(round(gap / period))
        if n > 1:
            filled.extend(filled[-1] + gap * k / n for k in range(1, n))
        filled.append(b)
    beats = np.array(filled)
    # nach vorne und hinten bis Songanfang/-ende verlängern
    head = np.arange(beats[0] - period, -period * 0.5, -period)[::-1]
    tail = np.arange(beats[-1] + period, mix_len_s + period, period)
    beats = np.concatenate([head, beats, tail])
    return beats, period


class Grid:
    """Feinraster mit 4 Schritten pro Beat, folgt den getrackten Beats."""
    def __init__(self, beats):
        self.beats = beats
        k = np.arange(len(beats))
        self.fine = np.interp(np.arange(0, len(beats) - 1 + 1e-9, 0.25), k, beats)
        self.period = float(np.median(np.diff(beats)))

    def index(self, t):
        i = int(np.searchsorted(self.fine, t))
        if i <= 0:
            return 0
        if i >= len(self.fine):
            return len(self.fine) - 1
        return i if self.fine[i] - t < t - self.fine[i - 1] else i - 1

    def step_quarters(self, level):
        """Rasterweite in Viertel-Beats, so dass die Noten nicht zu dicht werden."""
        level = BASE_LEVEL.get(level, level)
        for q in (1, 2, 4, 8, 16):
            if self.period * q / 4 >= MIN_STEP[level]:
                return q
        return 16


# ---------------------------------------------------------------- Drums
def drum_hits(drums):
    import librosa
    S = np.abs(librosa.stft(drums, n_fft=1024, hop_length=HOP)) ** 2
    f = librosa.fft_frequencies(sr=SR, n_fft=1024)

    def band_db(lo, hi):
        return 10 * np.log10(S[(f >= lo) & (f < hi)].sum(0) + 1e-10)

    low, mid, high = band_db(30, 150), band_db(300, 4000), band_db(6000, 11000)
    ref = {"low": np.percentile(low, 97), "mid": np.percentile(mid, 97), "high": np.percentile(high, 97)}
    env = librosa.onset.onset_strength(y=drums, sr=SR, hop_length=HOP, lag=1, max_size=3)
    frames = librosa.onset.onset_detect(onset_envelope=env, sr=SR, hop_length=HOP, backtrack=False, delta=0.07, wait=3)
    n = S.shape[1]
    hits = []
    for i in frames:
        a, b = max(0, i - 6), max(1, i - 1)
        lvl = lambda x: x[i:min(n, i + 3)].max()
        tail = lambda x: x[min(n - 1, i + 4):min(n, i + 10)].mean() if i + 5 < n else -120
        lo_l, mi_l, hi_l = lvl(low) - ref["low"], lvl(mid) - ref["mid"], lvl(high) - ref["high"]
        lo_r = lvl(low) - low[a:b].mean()
        mi_t, hi_t = tail(mid) - ref["mid"], tail(high) - ref["high"]
        kick = lo_l > -14 and lo_r > 6
        snare = mi_t > -30 and mi_l > -12
        hat = (not snare) and hi_l > -14 and mi_l < -3 and not kick
        if not (kick or snare or hat):
            continue
        hits.append({"t": float(i / FPS), "kick": bool(kick), "snare": bool(snare), "hat": bool(hat),
                     "power": float(max(lo_l, mi_l, hi_l))})
    # Doppel-Treffer (Flam, Nachhall) innerhalb von 70 ms zusammenfassen
    merged = []
    for h in hits:
        if merged and h["t"] - merged[-1]["t"] < 0.07:
            m = merged[-1]
            for k in ("kick", "snare", "hat"):
                m[k] = m[k] or h[k]
            if m["kick"] or m["snare"]:
                m["hat"] = False
            m["power"] = max(m["power"], h["power"])
        else:
            merged.append(dict(h))
    return merged


# ---------------------------------------------------------------- Melodie
def vocal_notes(vocals_path, device="cpu", progress=None):
    import librosa
    import torch
    import torchcrepe
    from scipy.ndimage import median_filter

    y = load_mono(vocals_path, sr=16000)
    rms = librosa.feature.rms(y=y, frame_length=1024, hop_length=160, center=True)[0]
    rms_db = 20 * np.log10(rms + 1e-9)
    loud = rms_db > np.percentile(rms_db, 95) - 28
    model = "full" if device == "cuda" else "tiny"
    f0_parts, pd_parts = [], []
    chunk = 16000 * 30
    for start in range(0, len(y), chunk):
        x = torch.tensor(y[start:start + chunk + 160])[None]
        f0, pd = torchcrepe.predict(x, 16000, hop_length=160, fmin=65, fmax=1100, model=model,
                                    decoder=torchcrepe.decode.viterbi, return_periodicity=True,
                                    batch_size=1024 if device == "cuda" else 256, device=device)
        keep = min(f0.shape[1], chunk // 160) if start + chunk < len(y) else f0.shape[1]
        f0_parts.append(f0[0, :keep].cpu().numpy())
        pd_parts.append(pd[0, :keep].cpu().numpy())
        if progress:
            progress(min(1.0, (start + chunk) / len(y)))
    f0 = np.concatenate(f0_parts)
    pdv = np.concatenate(pd_parts)
    m = min(len(f0), len(loud))
    f0, pdv, loud, rms_db = f0[:m], pdv[:m], loud[:m], rms_db[:m]
    voiced = (median_filter(pdv, 5) > 0.4) & loud
    midi = 69 + 12 * np.log2(np.maximum(f0, 1) / 440)
    midi_s = median_filter(midi, 7)

    # Silben-Anfänge auf der sauberen Gesangsspur
    env = librosa.onset.onset_strength(y=y, sr=16000, hop_length=160, lag=2, max_size=3)[:m]
    on = librosa.onset.onset_detect(onset_envelope=env, sr=16000, hop_length=160, backtrack=True,
                                    delta=0.04, wait=8, pre_avg=30, post_avg=30, pre_max=3, post_max=3)
    sing = loud & (rms_db > np.percentile(rms_db[loud], 25) - 6 if loud.any() else loud)
    starts = []
    for i in on:
        win = slice(i, min(m, i + 15))
        if sing[win].mean() < 0.5:
            continue
        if starts and i - starts[-1] < 9:
            continue
        starts.append(int(i))
    out = []
    for k, i in enumerate(starts):
        nxt = starts[k + 1] if k + 1 < len(starts) else m
        j = i + 3
        while j < nxt and (sing[j] or sing[min(m - 1, j + 1)] or sing[min(m - 1, j + 2)]):
            j += 1
        end = min(j, nxt)
        if end - i < 6:
            continue
        seg = slice(min(end - 1, i + 3), end)
        v = voiced[seg]
        pitch = float(np.median(midi_s[seg][v])) if v.sum() >= 3 else (out[-1]["pitch"] if out else 60.0)
        out.append({"t": i / 100, "end": end / 100, "pitch": pitch})
    return out


# ---------------------------------------------------------------- Notenplan
def snap(grid, t, q, phase=0):
    """Index der nächsten erlaubten Rasterposition (Viertel-Beat-Raster, Schritt q)."""
    i = grid.index(t)
    r = (i - phase) % q
    cand = [i - r, i - r + q]
    best = min(cand, key=lambda c: abs(grid.fine[max(0, min(len(grid.fine) - 1, c))] - t))
    return max(0, min(len(grid.fine) - 1, best))


def best_phase(grid, times, q):
    if q <= 1:
        return 0
    counts = np.zeros(q)
    for t in times:
        counts[grid.index(t) % q] += 1
    return int(np.argmax(counts))


CHORD_RULES = {
    # Abstand in Beats zwischen Griffen, Dreifachgriffe nur auf Taktanfang
    "easy":   {"pair_gap": 8, "triple_gap": None, "accent_pct": 90},
    "medium": {"pair_gap": 6, "triple_gap": None, "accent_pct": 88},
    "normal": {"pair_gap": 4, "triple_gap": 16, "accent_pct": 85},
    "pro":    {"pair_gap": 3, "triple_gap": 12, "accent_pct": 80},
    "hard":   {"pair_gap": 2, "triple_gap": 8, "accent_pct": 75},
}


TRIPLES = {
    5: [(0, 1, 2), (1, 2, 3), (2, 3, 4), (0, 1, 3), (0, 2, 3), (1, 3, 4), (1, 2, 4)],
    4: [(0, 1, 2), (1, 2, 3), (0, 1, 3), (0, 2, 3)],
}


def chord_pool(nl, size, level):
    if size == 3:
        return list(TRIPLES[nl])
    pairs = [(a, b) for a in range(nl) for b in range(a + 1, nl)]
    max_span = {"easy": 1, "medium": 1, "normal": 2, "pro": 3, "hard": nl - 1}[level]
    return [p for p in pairs if p[1] - p[0] <= max_span]


def drum_chart(hits, grid, level, nl=4, bar=0):
    q = grid.step_quarters(level)
    phase = best_phase(grid, [h["t"] for h in hits if h["snare"]] or [h["t"] for h in hits], q)
    tol = grid.period / 4 * 0.6
    slots = {}
    for h in hits:
        i = grid.index(h["t"])
        if abs(grid.fine[i] - h["t"]) > tol or (i - phase) % q:
            continue
        s = slots.setdefault(i, {"kick": False, "snare": False, "hat": False, "power": -99})
        for k in ("kick", "snare", "hat"):
            s[k] = s[k] or h[k]
        s["power"] = max(s["power"], h["power"])
    keep = thin_between(grid, level, list(slots), lambda i: slots[i]["power"],
                        [h["t"] for h in hits if h["snare"]] or [h["t"] for h in hits])
    slots = {i: v for i, v in slots.items() if i in keep}
    rules = CHORD_RULES[level]
    powers = [s["power"] for s in slots.values()]
    strong = np.percentile(powers, rules["accent_pct"]) if powers else 99
    # Einzelnoten: Kick links, Snare Mitte, Becken rechts; Wiederholungen wechseln die Spur
    if nl == 5:
        lanes = {"kick": (0, 1), "snare": (2, 3), "hat": (4, 2)}
    else:
        lanes = {"kick": (0, 1), "snare": (2, 3), "hat": (3, 2)}
    shift = {"kick": -1, "snare": 0, "hat": 1}
    alt = {"kick": 0, "snare": 0, "hat": 0}
    notes = []
    hand = nl // 2
    last_pair, last_triple = -99, -99
    last_shape, variety = None, 0
    for i in sorted(slots):
        s = slots[i]
        if level == "easy":
            cls = ["snare"] if s["snare"] else ["kick"] if s["kick"] else []
        else:
            cls = [c for c in ("kick", "snare") if s[c]] or (["hat"] if s["hat"] else [])
            if level in ("hard", "pro") and not cls and s["hat"]:
                cls = ["hat"]
        if not cls:
            continue
        beat = i / 4
        downbeat = i % 4 == 0 and (int(beat) - bar) % 4 == 0
        accent = (s["kick"] and s["snare"]) or s["power"] >= strong
        size = 1
        if accent:
            if rules["triple_gap"] and downbeat and s["kick"] and s["power"] >= strong and beat - last_triple >= rules["triple_gap"]:
                size = 3
            elif beat - last_pair >= rules["pair_gap"]:
                size = 2
        main = "snare" if "snare" in cls else cls[0]
        t = float(grid.fine[i])
        if size == 1:
            alt[main] ^= 1
            lane = lanes[main][alt[main]]
            hand = lane
            notes.append({"t": t, "lane": lane, "src": "drum", "pair": False, "slot": i})
            continue
        # Griffbild aus dem Vorrat wählen: nahe der Handposition, verschoben nach Klangfarbe, abwechslungsreich
        pool = chord_pool(nl, size, level)
        target = hand + shift[main] * 0.7
        pool.sort(key=lambda sh: (abs(sum(sh) / len(sh) - target), sh))
        near = [sh for sh in pool if abs(sum(sh) / len(sh) - target) <= 1.01] or pool[:3]
        if len(near) > 1 and last_shape in near:
            near.remove(last_shape)
        shape = list(near[variety % len(near)])
        variety += 1
        last_shape = tuple(shape)
        for lane in shape:
            notes.append({"t": t, "lane": lane, "src": "drum", "pair": True, "slot": i})
        hand = shape[len(shape) // 2]
        last_pair = beat
        if size == 3:
            last_triple = beat
    return notes


def melody_chart(mel, grid, level, nl=4):
    q = grid.step_quarters(level)
    used = {}
    for n in mel:
        i = snap(grid, n["t"], q)
        if abs(grid.fine[i] - n["t"]) > grid.period * q / 4 * 0.55:
            continue
        if i in used:
            continue
        used[i] = n
    keep = thin_between(grid, level, list(used), lambda i: used[i]["end"] - used[i]["t"], None)
    used = {i: v for i, v in used.items() if i in keep}
    slots = sorted(used)
    # Spur nach Tonhöhe: relative Lage im Umfeld (±8 s)
    notes = []
    last_lane, last_t = None, -9
    for idx, i in enumerate(slots):
        n = used[i]
        t = float(grid.fine[i])
        near = sorted({round(used[j]["pitch"]) for j in slots if abs(grid.fine[j] - t) < 6})
        rank = near.index(round(n["pitch"])) if round(n["pitch"]) in near else 0
        lane = int(min(nl - 1, rank * nl // max(1, len(near))))
        if lane == last_lane and t - last_t < 0.36:
            nxt_p = used[slots[idx + 1]]["pitch"] if idx + 1 < len(slots) else n["pitch"]
            lane = lane + 1 if (nxt_p >= n["pitch"] and lane < nl - 1) or lane == 0 else lane - 1
        note = {"t": t, "lane": lane, "src": "mel", "pair": False, "slot": i}
        nxt = float(grid.fine[slots[idx + 1]]) if idx + 1 < len(slots) else t + 99
        hold_min = max(0.5, grid.period * q / 4 * 1.5)
        if n["end"] - n["t"] >= hold_min:
            e = float(grid.fine[grid.index(n["end"])])
            e = min(e, nxt - 0.15)
            if e - t >= hold_min * 0.9:
                note["end"] = e
        notes.append(note)
        last_lane, last_t = lane, t
    return notes


def thin_holds(notes, grid, level, nl=5):
    """Macht Halte-Noten spielbar: nichts gleichzeitig, kaum etwas währenddessen, Luft danach."""
    q = grid.step_quarters(level)
    notes = sorted(notes, key=lambda n: (n["t"], n["lane"]))
    holds = [n for n in notes if "end" in n]
    drop = set()
    last_end = -9
    # Wo liegt die Greifhand? 4 Finger decken 4 nebeneinanderliegende Spuren ab; die Hand wandert mit den Noten.
    hand = {}
    w, i = 0, 0
    while i < len(notes):
        j = i
        while j < len(notes) and abs(notes[j]["t"] - notes[i]["t"]) < 1e-3:
            j += 1
        lanes = [n["lane"] for n in notes[i:j]]
        lo, hi = min(lanes), max(lanes)
        if hi > w + 3:
            w = hi - 3
        if lo < w:
            w = lo
        w = max(0, min(max(0, nl - 4), w))
        for n in notes[i:j]:
            hand[id(n)] = w
        i = j
    rest_after = max(0.2, grid.period * 0.5)          # Pause nach dem Loslassen
    no_chord_after = grid.period                      # einen Schlag lang keine Griffe
    for h in holds:
        if h["t"] < last_end + grid.period:           # nie zwei Halte-Noten gleichzeitig oder direkt hintereinander
            del h["end"]
            continue
        last_end = h["end"]
        for n in notes:
            if n is h or id(n) in drop or n["t"] < h["t"] - 0.01 or n["t"] > h["end"] + no_chord_after:
                continue
            if abs(n["t"] - h["t"]) < 0.01:            # nichts gleichzeitig mit dem Halte-Anfang
                drop.add(id(n)); continue
            if n["t"] > h["end"]:                      # nach dem Loslassen
                if n["t"] - h["end"] < rest_after or n.get("pair"):
                    drop.add(id(n))
                continue
            # während der Halte-Note
            if level in ("easy", "medium"):
                drop.add(id(n)); continue
            step = 4 * q if level == "normal" else 2 * q
            off_grid = (n["slot"] - h["slot"]) % step != 0
            if "end" in n or n.get("pair") or off_grid or n["t"] > h["end"] - 0.2:
                drop.add(id(n)); continue
            # Greifhand bleibt beim Halten liegen: frei sind die anderen 3 Finger im Handfenster
            hw = hand.get(id(h), 0)
            free = [l for l in range(hw, min(hw + 4, nl)) if l != h["lane"]]
            if n["lane"] not in free:
                if free:
                    n["lane"] = min(free, key=lambda l: (abs(l - n["lane"]), l))
                else:
                    drop.add(id(n))
    # Doppel-Partner, deren Gegenstück wegfiel, werden Einzelnoten
    kept = [n for n in notes if id(n) not in drop]
    by_t = {}
    for n in kept:
        by_t.setdefault(round(n["t"], 4), []).append(n)
    for group in by_t.values():
        if len(group) == 1:
            group[0]["pair"] = False
    return kept


def merge_chart(drums, mel, grid, level, nl=5):
    q = grid.step_quarters(level)
    taken = {n["slot"] for n in drums}
    out = [dict(n) for n in drums]
    for n in mel:
        if "end" in n:
            out = [d for d in out if abs(d["t"] - n["t"]) > 0.01]
            out.append(dict(n))
        elif not any(abs(n["slot"] - s) < q for s in taken):
            out.append(dict(n))
            taken.add(n["slot"])
    return thin_holds(out, grid, level, nl)


def finish(notes):
    res = []
    for n in sorted(notes, key=lambda n: (n["t"], n["lane"])):
        o = {"t": round(n["t"], 4), "lane": n["lane"], "src": n["src"]}
        if n.get("pair"):
            o["pair"] = True
        if "end" in n:
            o["end"] = round(n["end"], 4)
        res.append(o)
    return res


def analyse(song_dir, device="cpu", progress=None):
    import soundfile as sf
    say = progress or (lambda p, msg: None)
    stems = {}
    for s in ("drums", "vocals", "other", "bass"):
        mp3 = os.path.join(song_dir, s + ".mp3")
        stems[s] = mp3 if os.path.exists(mp3) else os.path.join(song_dir, s + ".wav")
    info = sf.info(os.path.join(song_dir, "mix.wav"))
    duration = info.frames / info.samplerate

    say(0.05, "Beats werden gesucht …")
    drums = load_mono(stems["drums"])
    grid_data = beat_grid(drums, duration)
    if grid_data is None:            # Song ohne Drums: Beat aus dem Gesamtmix
        import soundfile as sf2
        mix, msr = sf2.read(os.path.join(song_dir, "mix.wav"), dtype="float32", always_2d=True)
        import librosa
        grid_data = beat_grid(librosa.resample(mix.mean(1), orig_sr=msr, target_sr=SR), duration)
    beats, period = grid_data
    grid = Grid(beats)

    say(0.15, "Drums werden erkannt …")
    hits = drum_hits(drums)
    say(0.25, "Gesang wird erkannt …")
    mel = vocal_notes(stems["vocals"], device=device, progress=lambda p: say(0.25 + 0.7 * p, "Gesang wird erkannt …"))

    # Taktanfang: Snare/Clap auf 2 und 4
    score = np.zeros(4)
    for h in hits:
        if h["snare"]:
            k = int(round((grid.index(h["t"])) / 4))
            for o in range(4):
                if (k - o) % 4 in (1, 3):
                    score[o] += 1
    bar = int(np.argmax(score)) if score.any() else 0

    lane_sets = {}
    for nl in (4, 5):
        charts = {"drums": {}, "melody": {}, "mix": {}}
        for lv in LEVELS:
            d = drum_chart(hits, grid, lv, nl=nl, bar=bar)
            m = melody_chart(mel, grid, lv, nl=nl)
            charts["drums"][lv] = finish(thin_holds([dict(x) for x in d], grid, lv, nl))
            charts["melody"][lv] = finish(thin_holds([dict(x) for x in m], grid, lv, nl))
            charts["mix"][lv] = finish(merge_chart(d, m, grid, lv, nl))
        lane_sets[str(nl)] = charts
    result = {"version": VERSION, "bpm": round(60 / period, 2), "beats": [round(b, 4) for b in beats.tolist()],
              "bar": bar, "duration": duration, "charts": lane_sets["4"], "lanes": lane_sets,
              "stats": {"drumHits": len(hits), "vocalNotes": len(mel)}}
    with open(os.path.join(song_dir, "chart.json"), "w", encoding="utf-8") as f:
        json.dump(result, f, separators=(",", ":"))
    say(1.0, "Fertig.")
    return result
