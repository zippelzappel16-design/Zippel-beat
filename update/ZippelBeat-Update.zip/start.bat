@echo off
chcp 65001 >nul
title Zippel Beat Studio
cd /d "%~dp0"
set "VPY=%~dp0demucs-env\Scripts\python.exe"
set "UV=%~dp0tools\uv.exe"
set "SETUPONLY="
if /i "%~1"=="/setup" set "SETUPONLY=1"
rem nvidia-smi finden, auch wenn wir aus einem 32-Bit-Programm (z. B. dem Installer) gestartet wurden
set "NVSMI="
for %%X in (nvidia-smi.exe) do set "NVSMI=%%~$PATH:X"
if not defined NVSMI if exist "%SystemRoot%\Sysnative\nvidia-smi.exe" set "NVSMI=%SystemRoot%\Sysnative\nvidia-smi.exe"
if not defined NVSMI if exist "%SystemRoot%\System32\nvidia-smi.exe" set "NVSMI=%SystemRoot%\System32\nvidia-smi.exe"
if exist "%VPY%" goto update

echo.
echo   ZIPPEL BEAT STUDIO - Erste Einrichtung
echo   Alles wird automatisch in diesen Ordner installiert.
echo   Das dauert einmalig etwa 10 bis 20 Minuten.
echo.
if not exist "%UV%" call :getuv
if not exist "%UV%" goto nouv
echo   Eigenes Python 3.12 wird eingerichtet ...
"%UV%" venv --python 3.12 --managed-python demucs-env || goto fail
echo.
echo   Demucs wird installiert ...
"%UV%" pip install --python "%VPY%" demucs soundfile librosa torchcrepe || goto fail
rem Grafikkarten-PyTorch erst ganz zum Schluss, sonst ueberschreibt ein anderes Paket es wieder mit der Prozessor-Version
call :gpu
"%VPY%" -c "import demucs, soundfile, librosa, torchcrepe" || goto fail
echo.
echo   Einrichtung fertig.
echo.
goto run

:update
if not exist "%~dp0tools\gpu-geprueft" (
  call :gpurepair
  if not exist "%~dp0tools" mkdir "%~dp0tools"
  echo ok> "%~dp0tools\gpu-geprueft"
)
"%VPY%" -c "import librosa, torchcrepe" >nul 2>nul && goto run
echo.
echo   Update: Werkzeuge fuer die Noten-Erkennung werden nachinstalliert ...
"%UV%" pip install --python "%VPY%" librosa torchcrepe || goto updfail
call :gpurepair

:run
if defined SETUPONLY exit /b 0
"%VPY%" server.py
pause
exit /b 0

:getuv
echo   Lade Installationshelfer ...
if not exist "%~dp0tools" mkdir "%~dp0tools"
curl.exe -L --fail --silent --show-error -o "%~dp0tools\uv.zip" "https://github.com/astral-sh/uv/releases/latest/download/uv-x86_64-pc-windows-msvc.zip" || exit /b 0
tar -xf "%~dp0tools\uv.zip" -C "%~dp0tools"
del "%~dp0tools\uv.zip" >nul 2>nul
if not exist "%UV%" for /r "%~dp0tools" %%F in (uv.exe) do if exist "%%F" copy /y "%%F" "%UV%" >nul
exit /b 0

:gpu
if not defined NVSMI exit /b 0
echo.
set "CC="
for /f "tokens=1 delims=." %%A in ('""%NVSMI%"" --query-gpu^=compute_cap --format^=csv^,noheader 2^>nul') do if not defined CC set "CC=%%A"
set "CU=cu126"
if defined CC if %CC% GEQ 10 set "CU=cu128"
for /f "delims=" %%N in ('""%NVSMI%"" --query-gpu^=name --format^=csv^,noheader 2^>nul') do if not defined GPUNAME set "GPUNAME=%%N"
echo   Nvidia-Grafikkarte gefunden: %GPUNAME%
echo   PyTorch mit Grafikkarten-Support (%CU%) wird installiert, ca. 3 GB ...
"%UV%" pip install --python "%VPY%" --reinstall-package torch --reinstall-package torchaudio torch torchaudio --index-url https://download.pytorch.org/whl/%CU% && goto gpucheck
"%UV%" pip install --python "%VPY%" --reinstall-package torch --reinstall-package torchaudio torch torchaudio --index-url https://download.pytorch.org/whl/cu128 && goto gpucheck
echo   GPU-Version nicht verfuegbar, Demucs rechnet auf dem Prozessor.
exit /b 0
:gpucheck
"%VPY%" -c "import torch, sys; sys.exit(0 if torch.cuda.is_available() else 1)" >nul 2>nul
if errorlevel 1 (
  echo   Hinweis: Die Grafikkarte ist noch nicht nutzbar, das Studio rechnet erst mal auf dem Prozessor.
  echo   Meist hilft ein aktueller Nvidia-Treiber, danach "Grafikkarte aktivieren" starten.
) else (
  echo   Grafikkarte bereit.
)
exit /b 0

:gpurepair
if not defined NVSMI exit /b 0
"%VPY%" -c "import torch, sys; sys.exit(0 if torch.cuda.is_available() else 1)" >nul 2>nul && exit /b 0
echo   Grafikkarten-Version von PyTorch wird wiederhergestellt ...
call :gpu
exit /b 0

:updfail
echo.
echo   Das Nachinstallieren hat nicht geklappt. Schick die Meldung oben an Claude.
pause
exit /b 1

:nouv
echo.
echo   Der Installationshelfer konnte nicht geladen werden.
echo   Bitte Internetverbindung pruefen und start.bat erneut starten.
echo   Klappt es weiterhin nicht, schick die Meldung oben an Claude.
pause
exit /b 1

:fail
echo.
echo   Die Einrichtung ist fehlgeschlagen. Schick die Meldung oben an Claude.
if exist demucs-env ren demucs-env demucs-env-kaputt-%RANDOM% >nul 2>nul
echo   Danach start.bat einfach neu starten.
pause
exit /b 1
