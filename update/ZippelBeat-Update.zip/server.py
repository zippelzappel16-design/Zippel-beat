#!/usr/bin/env python3
"""Zippel Beat Studio

Lokaler Server: liefert das Spiel an den Browser aus und trennt Songs
mit Demucs in Drums, Bass, Gesang und Instrumente. Alles bleibt auf
diesem Rechner. Getrennte Songs landen im Ordner "bibliothek".
"""
import hashlib
import hmac
import secrets
import json
import os
import re
import shutil
import sys
import threading
import time
import traceback
import urllib.parse
import uuid
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

ROOT = os.path.dirname(os.path.abspath(__file__))
LIB = os.path.join(ROOT, "bibliothek")
PORT = int(os.environ.get("ZIPPEL_PORT", "8765"))
os.makedirs(LIB, exist_ok=True)

JOBS = {}
WORK = threading.Lock()      # immer nur eine Trennung gleichzeitig
MODEL = {}
DEVICE = {"device": None, "name": "wird geprüft …"}


def log(*args):
    print(time.strftime("%H:%M:%S"), *args, flush=True)


# ---------- Bibliothek ----------
def read_meta(song_dir):
    try:
        with open(os.path.join(song_dir, "meta.json"), encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def update_meta(song_dir, **values):
    meta = read_meta(song_dir)
    meta.update(values)
    with open(os.path.join(song_dir, "meta.json"), "w", encoding="utf-8") as f:
        json.dump(meta, f, ensure_ascii=False, indent=2)
    return meta


def library():
    songs = []
    for sid in os.listdir(LIB):
        d = os.path.join(LIB, sid)
        meta = read_meta(d)
        if os.path.isdir(d) and (meta.get("stems") or meta.get("bundled")):
            songs.append({"id": sid, "name": meta.get("name", sid), "created": meta.get("created", 0),
                          "stems": meta.get("stems") or [], "bundled": bool(meta.get("bundled"))})
    return sorted(songs, key=lambda s: s["created"], reverse=True)


# ---------- Demucs ----------
def detect_device():
    """Prüft, ob die Grafikkarte wirklich rechnen kann (neue Karten brauchen passende PyTorch-Builds)."""
    if DEVICE["device"]:
        return DEVICE["device"]
    import torch
    device, name = "cpu", "Prozessor"
    if torch.cuda.is_available():
        try:
            x = torch.randn(1, 2, 4096, device="cuda")
            torch.nn.functional.conv1d(x, torch.randn(4, 2, 8, device="cuda")).sum().item()
            device, name = "cuda", torch.cuda.get_device_name(0)
        except Exception as e:
            log("Grafikkarte gefunden, aber nicht nutzbar:", e)
            log("Tipp: gpu-aktivieren.bat ausführen.")
    DEVICE.update(device=device, name=name)
    log("Rechnet auf:", name)
    return device


def load_model(job):
    if "model" not in MODEL:
        job["message"] = "Demucs-Modell wird geladen (beim ersten Mal ca. 80 MB Download) …"
        import torch
        from demucs.pretrained import get_model
        model = get_model("htdemucs")
        model.eval()
        device = detect_device()
        model.to(device)
        MODEL.update(model=model, device=device)
        log("Modell bereit.")
    return MODEL["model"], MODEL["device"]


def install_progress_hook(job):
    """Fängt die Fortschrittsanzeige von Demucs ab und meldet sie an den Browser."""
    import demucs.apply as demucs_apply

    class Progress:
        def __init__(self, iterable, *args, **kwargs):
            self.items = list(iterable)

        def __iter__(self):
            total = max(1, len(self.items))
            for i, item in enumerate(self.items):
                job["progress"] = min(60, int(60 * i / total))
                yield item
            job["progress"] = 60

    target = demucs_apply.tqdm
    if hasattr(target, "tqdm"):
        target.tqdm = Progress
    else:
        demucs_apply.tqdm = Progress


def separate(job_id, song_dir):
    job = JOBS[job_id]
    with WORK:
        try:
            job.update(state="running", progress=0)
            import soundfile as sf
            import torch
            from demucs.apply import apply_model
            from demucs.audio import save_audio

            model, device = load_model(job)
            install_progress_hook(job)
            job["message"] = "Demucs trennt die Spuren …"
            started = time.time()

            data, sr = sf.read(os.path.join(song_dir, "mix.wav"), dtype="float32", always_2d=True)
            wav = torch.from_numpy(data.T.copy())
            if wav.shape[0] == 1:
                wav = wav.repeat(2, 1)
            wav = wav[:2]
            ref = wav.mean(0)
            mean, std = ref.mean(), ref.std() + 1e-8

            with torch.no_grad():
                sources = apply_model(model, ((wav - mean) / std)[None].to(device),
                                      split=True, overlap=0.25, progress=True, device=device)[0]
            sources = (sources * std + mean).cpu()

            files = []
            for name, src in zip(model.sources, sources):
                try:
                    save_audio(src, os.path.join(song_dir, name + ".mp3"), samplerate=model.samplerate, bitrate=256)
                    files.append(name + ".mp3")
                except Exception:
                    sf.write(os.path.join(song_dir, name + ".wav"), src.numpy().T, model.samplerate)
                    files.append(name + ".wav")
            update_meta(song_dir, stems=files)
            log(f"Getrennt in {time.time() - started:.0f} s:", read_meta(song_dir).get("name"))
            run_analysis(job, song_dir, device, start=60)
        except Exception as e:
            traceback.print_exc()
            job.update(state="error", message=f"{type(e).__name__}: {e}")


def run_analysis(job, song_dir, device, start=0):
    """Notenplan aus den Stems berechnen (Beats, Drums, Gesang) und als chart.json speichern."""
    import analyse
    started = time.time()

    def progress(p, msg):
        job["progress"] = int(start + (100 - start) * min(1.0, p) * 0.99)
        job["message"] = msg
    analyse.analyse(song_dir, device=device, progress=progress)
    log(f"Noten berechnet in {time.time() - started:.0f} s.")
    job.update(state="done", progress=100, message="Fertig.")


def analyse_job(job_id, song_dir):
    job = JOBS[job_id]
    with WORK:
        try:
            job.update(state="running", progress=0, message="Noten werden berechnet …")
            run_analysis(job, song_dir, detect_device())
        except Exception as e:
            traceback.print_exc()
            job.update(state="error", message=f"{type(e).__name__}: {e}")


EXPORT_LOCK = threading.Lock()
EXPORT_FAILED = set()


def export_audio(song_dir):
    """Liefert den Song als OGG (Vorbis). Wird beim ersten Mal aus mix.wav erzeugt.
    Das Spiel lädt Songs immer so: rund zehnmal kleiner als WAV, und große WAV-Übertragungen
    werden auf manchen PCs (z. B. vom Virenscanner) mittendrin abgebrochen."""
    if not os.path.isdir(song_dir):
        return None
    ogg = os.path.join(song_dir, "mix.ogg")
    if os.path.isfile(ogg):
        return ogg
    wav = os.path.join(song_dir, "mix.wav")
    if not os.path.isfile(wav):
        return None
    with EXPORT_LOCK:
        if os.path.isfile(ogg):
            return ogg
        return _export(wav, ogg)


def _export(wav, ogg):
    try:
        import soundfile as sf
        tmp = ogg + ".tmp"
        with sf.SoundFile(wav) as src, sf.SoundFile(tmp, "w", samplerate=src.samplerate, channels=src.channels,
                                                    format="OGG", subtype="VORBIS") as dst:
            for block in src.blocks(blocksize=65536, dtype="float32", always_2d=True):
                dst.write(block)
        os.replace(tmp, ogg)
        log("Als OGG gespeichert:", read_meta(os.path.dirname(ogg)).get("name"))
        return ogg
    except Exception as e:
        EXPORT_FAILED.add(wav)
        try:
            os.remove(ogg + ".tmp")
        except OSError:
            pass
        log("OGG-Export nicht möglich, schicke WAV:", e)
        return wav


def chart_ready(song_dir):
    try:
        import analyse
        with open(os.path.join(song_dir, "chart.json"), encoding="utf-8") as f:
            data = json.load(f)
        if data.get("version") == analyse.VERSION:
            return data
        # Mitgelieferte Songs haben keine Spuren zum Neuberechnen: ihr fertiger Notenplan gilt weiter
        return data if read_meta(song_dir).get("bundled") and not read_meta(song_dir).get("stems") else None
    except Exception:
        return None


WORK_SCORES = threading.Lock()


# ---------- Bestenliste mit Unterschrift ----------
# Jeder Eintrag wird mit einem geheimen Schlüssel unterschrieben (HMAC-SHA256).
# Wer scores.json von Hand bearbeitet, macht die Unterschrift ungültig;
# solche Einträge werden beim Laden verworfen.
_PEPPER = b"zb\x7f\x13studio\x99beat\x42v1"
_SIGN_FIELDS = ("name", "score", "hits", "total", "stars", "fc", "combo", "date")


def _install_key():
    path = os.path.join(LIB, ".zb-schluessel")
    try:
        with open(path, "rb") as f:
            raw = f.read()
        if len(raw) == 32:
            return hashlib.sha256(_PEPPER + raw).digest()
    except FileNotFoundError:
        pass
    raw = secrets.token_bytes(32)
    with open(path, "wb") as f:
        f.write(raw)
    if os.name == "nt":
        try:
            import ctypes
            ctypes.windll.kernel32.SetFileAttributesW(path, 0x02)   # versteckt
        except Exception:
            pass
    return hashlib.sha256(_PEPPER + raw).digest()


_KEY = None


def _sig(song_id, list_key, e):
    global _KEY
    if _KEY is None:
        _KEY = _install_key()
    msg = json.dumps([song_id, list_key] + [e.get(k) for k in _SIGN_FIELDS], ensure_ascii=False, separators=(",", ":"))
    return hmac.new(_KEY, msg.encode("utf-8"), hashlib.sha256).hexdigest()


def _write_scores(song_dir, lists):
    with open(os.path.join(song_dir, "scores.json"), "w", encoding="utf-8") as f:
        json.dump({"v": 2, "lists": lists}, f, ensure_ascii=False, indent=1)


def read_scores(song_dir, verified=True):
    """Liefert {Listen-Schlüssel: [Einträge]} – nur Einträge mit gültiger Unterschrift."""
    song_id = os.path.basename(song_dir)
    try:
        with open(os.path.join(song_dir, "scores.json"), encoding="utf-8") as f:
            data = json.load(f)
    except Exception:
        return {}
    if not isinstance(data, dict):
        return {}
    if data.get("v") != 2:
        # Unsignierte Liste: nur bei der einmaligen Umstellung (migrate_all) gültig, sonst verwerfen
        log("Unsignierte Bestenliste verworfen:", song_id)
        _write_scores(song_dir, {})
        return {}
    out, dropped = {}, 0
    for k, v in (data.get("lists") or {}).items():
        good = []
        for e in v if isinstance(v, list) else []:
            if isinstance(e, dict) and hmac.compare_digest(str(e.get("sig", "")), _sig(song_id, k, e)):
                good.append(e)
            else:
                dropped += 1
        out[k] = sorted(good, key=lambda x: -x["score"])[:10]
    if dropped:
        log(f"{dropped} manipulierte(r) Eintrag/Einträge in der Bestenliste verworfen:", song_id)
        _write_scores(song_dir, out)
    return out


def migrate_all():
    """Einmalig beim ersten Start mit Unterschrift: vorhandene Listen übernehmen und unterschreiben.
    Danach werden unsignierte Listen nie wieder akzeptiert."""
    if os.path.exists(os.path.join(LIB, ".zb-schluessel")):
        return
    _sig("", "", {})            # erzeugt den Schlüssel
    for sid in os.listdir(LIB):
        f = os.path.join(LIB, sid, "scores.json")
        try:
            with open(f, encoding="utf-8") as fh:
                data = json.load(fh)
        except Exception:
            continue
        if not isinstance(data, dict) or data.get("v") == 2:
            continue
        lists = {k: [dict(e, sig=_sig(sid, k, e)) for e in v if isinstance(e, dict) and "score" in e]
                 for k, v in data.items() if isinstance(v, list)}
        _write_scores(os.path.join(LIB, sid), lists)
        log("Bestenliste übernommen und unterschrieben:", sid)


def public_scores(song_dir):
    return {k: [{f: e.get(f) for f in _SIGN_FIELDS} for e in v] for k, v in read_scores(song_dir).items()}


# ---------- Webserver ----------
class Handler(BaseHTTPRequestHandler):
    server_version = "ZippelBeatStudio/1"

    def log_message(self, fmt, *args):
        pass

    def send_json(self, obj, code=200):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def send_file(self, path, ctype):
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(os.path.getsize(path)))
        self.end_headers()
        with open(path, "rb") as f:
            shutil.copyfileobj(f, self.wfile)

    def do_GET(self):
        path = urllib.parse.urlparse(self.path).path
        if path in ("/", "/index.html"):
            return self.send_file(os.path.join(ROOT, "index.html"), "text/html; charset=utf-8")
        if path == "/peerjs.min.js":  # Baustein fürs Online-Duell (liegt bei, kein Internet-CDN nötig)
            return self.send_file(os.path.join(ROOT, "peerjs.min.js"), "text/javascript; charset=utf-8")
        if path == "/api/ping":
            return self.send_json({"zippel": True, "version": 3, "device": DEVICE["device"], "deviceName": DEVICE["name"]})
        if path == "/api/library":
            return self.send_json(library())
        m = re.fullmatch(r"/api/job/([0-9a-f]+)", path)
        if m:
            job = JOBS.get(m.group(1))
            return self.send_json(job or {"state": "unknown", "message": "Auftrag unbekannt"}, 200 if job else 404)
        m = re.fullmatch(r"/api/export/([0-9a-f]{16})", path)
        if m:  # Song fürs Online-Duell: platzsparend als OGG (wird einmal erzeugt und behalten)
            song_dir = os.path.join(LIB, m.group(1))
            f = export_audio(song_dir)
            if not f:
                return self.send_json({"error": "Song nicht gefunden"}, 404)
            return self.send_file(f, "audio/ogg" if f.endswith(".ogg") else "audio/wav")
        m = re.fullmatch(r"/api/scores/([0-9a-f]{16})", path)
        if m:
            return self.send_json(public_scores(os.path.join(LIB, m.group(1))))
        m = re.fullmatch(r"/api/chart/([0-9a-f]{16})", path)
        if m:
            song_dir = os.path.join(LIB, m.group(1))
            if not os.path.isdir(song_dir):
                return self.send_json({"error": "Song nicht gefunden"}, 404)
            data = chart_ready(song_dir)
            if data:
                return self.send_json({"chart": data})
            for jid, job in JOBS.items():
                if job.get("id") == m.group(1) and job["state"] in ("queued", "running"):
                    return self.send_json({"job": jid})
            jid = uuid.uuid4().hex
            JOBS[jid] = {"state": "queued", "progress": 0, "message": "Wartet …", "id": m.group(1)}
            threading.Thread(target=analyse_job, args=(jid, song_dir), daemon=True).start()
            return self.send_json({"job": jid})
        m = re.fullmatch(r"/lib/([0-9a-f]{16})/([a-z]+\.(?:mp3|wav))", path)
        if m:
            f = os.path.join(LIB, m.group(1), m.group(2))
            if os.path.isfile(f):
                return self.send_file(f, "audio/mpeg" if f.endswith(".mp3") else "audio/wav")
            if m.group(2) == "mix.wav":  # mitgelieferte Songs liegen platzsparend als Opus vor
                for alt, mime in (("mix.ogg", "audio/ogg"), ("mix.mp3", "audio/mpeg")):
                    f = os.path.join(LIB, m.group(1), alt)
                    if os.path.isfile(f):
                        return self.send_file(f, mime)
        self.send_error(404)

    def do_POST(self):
        path = urllib.parse.urlparse(self.path).path
        m = re.fullmatch(r"/api/import/([0-9a-f]{16})(/chart)?", path)
        if m:  # Song vom Duell-Partner übernehmen (fertige Noten, ohne Spuren)
            size = int(self.headers.get("Content-Length") or 0)
            if size <= 0 or size > 300 * 1024 * 1024:
                return self.send_json({"error": "Ungültige Daten"}, 400)
            data = self.rfile.read(size)
            song_dir = os.path.join(LIB, m.group(1))
            if m.group(2):
                try:
                    chart = json.loads(data.decode("utf-8"))
                    assert isinstance(chart, dict) and "charts" in chart or "lanes" in chart
                except Exception:
                    return self.send_json({"error": "Notenplan ungültig"}, 400)
                if not os.path.exists(os.path.join(song_dir, "chart.json")):
                    os.makedirs(song_dir, exist_ok=True)
                    with open(os.path.join(song_dir, "chart.json"), "w", encoding="utf-8") as f:
                        json.dump(chart, f, ensure_ascii=False, separators=(",", ":"))
                return self.send_json({"ok": True})
            ext = "ogg" if (self.headers.get("X-Ext") or "") == "ogg" else "wav"
            name = urllib.parse.unquote(self.headers.get("X-Filename") or "Song")[:120]
            os.makedirs(song_dir, exist_ok=True)
            if not read_meta(song_dir).get("stems"):
                with open(os.path.join(song_dir, "mix." + ext), "wb") as f:
                    f.write(data)
                update_meta(song_dir, name=name, created=time.time(), bundled=True, stems=[])
                log("Song vom Duell-Partner übernommen:", name)
            return self.send_json({"ok": True})
        if path == "/api/separate":
            size = int(self.headers.get("Content-Length") or 0)
            if size <= 44 or size > 800 * 1024 * 1024:
                return self.send_json({"error": "Ungültige Datei"}, 400)
            data = self.rfile.read(size)
            name = urllib.parse.unquote(self.headers.get("X-Filename") or "Song")[:120]
            sid = hashlib.sha1(data).hexdigest()[:16]
            song_dir = os.path.join(LIB, sid)
            meta = read_meta(song_dir)
            if meta.get("stems") and chart_ready(song_dir):
                return self.send_json({"id": sid, "job": None, "cached": True})
            if meta.get("stems"):
                jid = uuid.uuid4().hex
                JOBS[jid] = {"state": "queued", "progress": 0, "message": "Wartet …", "id": sid}
                threading.Thread(target=analyse_job, args=(jid, song_dir), daemon=True).start()
                return self.send_json({"id": sid, "job": jid})
            for jid, job in JOBS.items():
                if job.get("id") == sid and job["state"] in ("queued", "running"):
                    return self.send_json({"id": sid, "job": jid})
            os.makedirs(song_dir, exist_ok=True)
            with open(os.path.join(song_dir, "mix.wav"), "wb") as f:
                f.write(data)
            update_meta(song_dir, name=name, created=time.time())
            jid = uuid.uuid4().hex
            JOBS[jid] = {"state": "queued", "progress": 0, "message": "Wartet auf Demucs …", "id": sid}
            log("Neuer Song:", name)
            threading.Thread(target=separate, args=(jid, song_dir), daemon=True).start()
            return self.send_json({"id": sid, "job": jid})
        m = re.fullmatch(r"/api/scores/([0-9a-f]{16})", path)
        if m:
            song_dir = os.path.join(LIB, m.group(1))
            if not os.path.isdir(song_dir):
                return self.send_json({"error": "Song nicht gefunden"}, 404)
            try:
                size = int(self.headers.get("Content-Length") or 0)
                body = json.loads(self.rfile.read(min(size, 20000)).decode("utf-8"))
                key = str(body["key"])[:60]
                e = body["entry"]
                entry = {"name": (str(e.get("name") or "Anonym").strip() or "Anonym")[:20],
                         "score": int(e["score"]), "hits": int(e["hits"]), "total": int(e["total"]),
                         "stars": max(0, min(5, int(e["stars"]))), "fc": bool(e.get("fc")),
                         "combo": int(e.get("combo", 0)), "date": int(e.get("date", time.time() * 1000))}
            except Exception:
                return self.send_json({"error": "Ungültiger Eintrag"}, 400)
            with WORK_SCORES:
                data = read_scores(song_dir)
                entry["sig"] = _sig(m.group(1), key, entry)
                lst = sorted(data.get(key, []) + [entry], key=lambda x: -x["score"])[:10]
                data[key] = lst
                _write_scores(song_dir, data)
            return self.send_json({"list": [{f: e.get(f) for f in _SIGN_FIELDS} for e in lst]})
        m = re.fullmatch(r"/api/delete/([0-9a-f]{16})", path)
        if m:
            shutil.rmtree(os.path.join(LIB, m.group(1)), ignore_errors=True)
            return self.send_json({"ok": True})
        self.send_error(404)


def export_all():
    """Im Hintergrund alle Songs ohne OGG umwandeln, damit sie später sofort laden."""
    time.sleep(5)
    while True:
        for s in library():
            d = os.path.join(LIB, s["id"])
            wav = os.path.join(d, "mix.wav")
            if not os.path.isfile(os.path.join(d, "mix.ogg")) and os.path.isfile(wav) and wav not in EXPORT_FAILED:
                if WORK.locked():      # Demucs hat Vorrang
                    break
                export_audio(d)
                time.sleep(.5)
        time.sleep(30)


def main():
    try:
        import demucs  # noqa: F401
        import soundfile  # noqa: F401
        import librosa  # noqa: F401
        import torchcrepe  # noqa: F401
    except ImportError as e:
        print("Demucs ist nicht installiert:", e)
        print("Bitte start.bat (Windows) bzw. start.sh (Mac/Linux) benutzen, das richtet alles ein.")
        sys.exit(1)
    try:
        server = ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
    except OSError:
        print(f"Port {PORT} ist belegt. Läuft Zippel Beat Studio schon in einem anderen Fenster?")
        if not os.environ.get("ZIPPEL_NOBROWSER"):
            webbrowser.open(f"http://localhost:{PORT}/")
        sys.exit(1)
    url = f"http://localhost:{PORT}/"
    print()
    print("  ZIPPEL BEAT STUDIO läuft")
    print(f"  Im Browser: {url}")
    print("  Dieses Fenster offen lassen. Zum Beenden einfach schließen.")
    print()
    migrate_all()
    threading.Thread(target=detect_device, daemon=True).start()
    threading.Thread(target=export_all, daemon=True).start()
    if not os.environ.get("ZIPPEL_NOBROWSER"):  # die Desktop-App zeigt das Spiel im eigenen Fenster
        threading.Timer(1.5, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
